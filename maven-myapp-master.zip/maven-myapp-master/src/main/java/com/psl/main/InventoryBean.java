package com.psl.main;

public class InventoryBean {

	private String manufacturer;
	private String carName;
	private String colorsAvailable;
	private String price;

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getColorsAvailable() {
		return colorsAvailable;
	}

	public void setColorsAvailable(String colorsAvailable) {
		this.colorsAvailable = colorsAvailable;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

}
