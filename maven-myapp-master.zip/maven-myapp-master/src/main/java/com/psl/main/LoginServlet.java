package com.psl.main;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.psl.main.LoginBean;
import com.psl.main.LoginDAO;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public LoginServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try
		{
			
			if("Get Inventory".equals(request.getParameter("commit"))){
				
				
				InventoryDAO.InvLogic();
				response.sendRedirect("InventoryDetails.jsp");
			}else{
				LoginBean user = new LoginBean();
				user.setUserName(request.getParameter("uname"));
				user.setPassword(request.getParameter("password"));
				user = LoginDAO.login(user);
				if(user.isValid())
				{
					HttpSession session = request.getSession(true);
					session.setAttribute("currentSessionUser",user);
					response.sendRedirect("LoginSuccess.jsp");
				}else
					response.sendRedirect("LoginFailed.jsp");
			}
		} catch (Throwable exc)
		{
			exc.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
